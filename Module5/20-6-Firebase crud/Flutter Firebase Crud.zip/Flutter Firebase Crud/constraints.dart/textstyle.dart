import 'package:flutter/material.dart';

var txt = const TextStyle(
  fontSize: 22,
  fontWeight: FontWeight.bold,
);
var txt2 = const TextStyle(
  fontSize: 18,
);
